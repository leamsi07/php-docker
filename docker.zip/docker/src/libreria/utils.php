<?php

$cedu =$_GET['cedula'];
$url= "http://173.249.49.169:88/api/test/consulta/".$cedu;

$json = file_get_contents($url);
$json = json_encode($json);

