<?php
include('content.php'); 
?>
<h5>Pacientes</h5>

<div class="left-align">
</div>
<table>
  <thead>
    <tr>
       
        <th></th>
        <th>Cedula</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Edad</th>
    </tr>
  </thead>
  <tbody class ="striped">
  <?php
$files = scandir('datos');
 foreach($files as $file){
     $path = "datos/{$file}";
     if(is_file($path)){
         $data = file_get_contents($path);
         $data = json_decode($data,1);
         $d = age($data['FechaNacimiento']);
         echo "  
         <tr>
        <td>
            <img style = 'height:100px' src ='{$data['Foto']}'.jpg'/></td>
        
              <td>{$data['Cedula']}</td>
              <td>{$data['Nombres']}</td>
              <td>{$data['Apellido1']}</td>
              <td>{$d}</td>
              </td>
         </tr>
         
         ";
     }
        }
?>
  </tbody>
</table>
  <?php
include('footer.php'); 
?>