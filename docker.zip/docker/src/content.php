

<?php 

include('libreria/utils.php');
include('header.php');
if($_GET){
    $dir =  "datos";
    if(!is_dir($dir)){
      mkdir($dir);
    }
    
    $contenido = json_decode($json);
    file_put_contents("{$dir}/{$_GET['cedula']}.json", $contenido);
   
    header("location:index.php");
    }

   function age($fechanacimiento){
        list($ano,$mes,$dia) = explode("-",$fechanacimiento);
        $ano_diferencia  = date('Y') - $ano;
        $mes_diferencia = date('m') - $mes;
        $dia_diferencia   = date('d') - $dia;
        if ($dia_diferencia < 0 || $mes_diferencia < 0)
          $ano_diferencia--;
        return $ano_diferencia;
      }

?>
<div class="row">
    <form class="col s12" method="get" >
      <div class="row">
        <div class="input-field col s6">
          <input placeholder="Ingrese Cedula" name= "cedula" id="cedula" type="text" class="validate">
          <label for="cedula">Cedula</label>
        </div>
        <div class="input-field col s6">
          <input id="fecha" name="fecha" type="text" class="validate">
          <label for="fecha">Fecha Infeccion</label>
        </div>
        <div class ="center-align">
        <button class ="btn" type ="submit">
          Buscar
           </button>
        </div>
    </form>
      </div>
      <script>
$('#fecha').mask('0/00/0000');
</script>